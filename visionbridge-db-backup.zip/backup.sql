--
-- PostgreSQL database dump
--

\restrict X7F7JsnyxpaCtafVoLjvf7JXDNUubJHO1LpDgLPoiDEpb5NJeCCX5iZ1uwDChFQ

-- Dumped from database version 17.8 (a48d9ca)
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.activities (
    id integer NOT NULL,
    type character varying(50),
    icon character varying(10),
    title character varying(255),
    description text,
    color character varying(20),
    created_at timestamp without time zone DEFAULT ((CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) AT TIME ZONE 'Asia/Kolkata'::text)
);


ALTER TABLE public.activities OWNER TO neondb_owner;

--
-- Name: activities_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activities_id_seq OWNER TO neondb_owner;

--
-- Name: activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    entity_type character varying(50),
    entity_id character varying(50),
    action character varying(20),
    performed_by character varying(50),
    performed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_logs OWNER TO neondb_owner;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO neondb_owner;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: client_notes; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.client_notes (
    id integer NOT NULL,
    client_id integer,
    note text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.client_notes OWNER TO neondb_owner;

--
-- Name: client_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.client_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.client_notes_id_seq OWNER TO neondb_owner;

--
-- Name: client_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.client_notes_id_seq OWNED BY public.client_notes.id;


--
-- Name: client_sequence; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.client_sequence (
    id integer NOT NULL,
    last_number integer NOT NULL
);


ALTER TABLE public.client_sequence OWNER TO neondb_owner;

--
-- Name: client_sequence_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.client_sequence_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.client_sequence_id_seq OWNER TO neondb_owner;

--
-- Name: client_sequence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.client_sequence_id_seq OWNED BY public.client_sequence.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    full_name character varying(100) NOT NULL,
    date_of_birth date,
    age integer,
    risk_profile character varying(20),
    sourcing_type character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    age_bucket character varying(20),
    client_added_by character varying(100),
    client_sourcing character varying(20),
    mobile_number character varying(15),
    monthly_income numeric,
    investment_experience character varying(20),
    pan character varying(10),
    aadhaar character varying(12),
    nominee_name character varying(100),
    nominee_relation character varying(50),
    nominee_mobile character varying(15),
    client_notes character varying(500),
    is_active boolean DEFAULT true,
    client_code character varying(10),
    onboarding_date date DEFAULT CURRENT_DATE,
    added_by character varying(50),
    sourcing character varying(50),
    notes text,
    email character varying(100),
    dob date
);


ALTER TABLE public.clients OWNER TO neondb_owner;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clients_id_seq OWNER TO neondb_owner;

--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: market_value_aum; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.market_value_aum (
    id integer NOT NULL,
    month_year date NOT NULL,
    total_market_value numeric(18,2) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.market_value_aum OWNER TO neondb_owner;

--
-- Name: market_value_aum_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.market_value_aum_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.market_value_aum_id_seq OWNER TO neondb_owner;

--
-- Name: market_value_aum_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.market_value_aum_id_seq OWNED BY public.market_value_aum.id;


--
-- Name: mf_schemes; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.mf_schemes (
    id integer NOT NULL,
    scheme_name character varying(150) NOT NULL,
    amc_name character varying(150) NOT NULL,
    category character varying(20) NOT NULL,
    sub_category character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    large_cap numeric DEFAULT 0,
    mid_cap numeric DEFAULT 0,
    small_cap numeric DEFAULT 0,
    total_equity numeric DEFAULT 0,
    debt numeric DEFAULT 0,
    gold numeric DEFAULT 0,
    allocation numeric(5,2) DEFAULT 100.00,
    debt_allocation numeric(5,2) DEFAULT 0,
    gold_allocation numeric(5,2) DEFAULT 0,
    commission_rate numeric(5,2) DEFAULT 0.80,
    total_current_value numeric(15,2) DEFAULT 0.00,
    CONSTRAINT mf_schemes_category_check CHECK (((category)::text = ANY ((ARRAY['Equity'::character varying, 'Debt'::character varying, 'Hybrid'::character varying, 'Gold'::character varying])::text[])))
);


ALTER TABLE public.mf_schemes OWNER TO neondb_owner;

--
-- Name: mf_schemes_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.mf_schemes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mf_schemes_id_seq OWNER TO neondb_owner;

--
-- Name: mf_schemes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.mf_schemes_id_seq OWNED BY public.mf_schemes.id;


--
-- Name: monthly_analytics; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.monthly_analytics (
    id integer NOT NULL,
    snapshot_date date DEFAULT CURRENT_DATE,
    total_invested numeric(20,2) DEFAULT 0,
    total_market_value numeric(20,2) DEFAULT 0,
    sip_book_amount numeric(20,2) DEFAULT 0,
    actual_commission numeric(20,2) DEFAULT 0
);


ALTER TABLE public.monthly_analytics OWNER TO neondb_owner;

--
-- Name: monthly_analytics_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.monthly_analytics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.monthly_analytics_id_seq OWNER TO neondb_owner;

--
-- Name: monthly_analytics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.monthly_analytics_id_seq OWNED BY public.monthly_analytics.id;


--
-- Name: playing_with_neon; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.playing_with_neon (
    id integer NOT NULL,
    name text NOT NULL,
    value real
);


ALTER TABLE public.playing_with_neon OWNER TO neondb_owner;

--
-- Name: playing_with_neon_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.playing_with_neon_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playing_with_neon_id_seq OWNER TO neondb_owner;

--
-- Name: playing_with_neon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.playing_with_neon_id_seq OWNED BY public.playing_with_neon.id;


--
-- Name: sips; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sips (
    id integer NOT NULL,
    client_id integer NOT NULL,
    frequency character varying(20) NOT NULL,
    start_date date NOT NULL,
    end_date date,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    sip_day character varying(15),
    status character varying(10) DEFAULT 'ACTIVE'::character varying,
    stopped_at date,
    scheme_name character varying,
    platform character varying(50) DEFAULT 'NSE'::character varying,
    notes text,
    sip_id character varying(20),
    scheme_id integer,
    amount numeric(15,2),
    CONSTRAINT chk_sip_frequency CHECK (((frequency)::text = ANY ((ARRAY['MONTHLY'::character varying, 'WEEKLY'::character varying])::text[])))
);


ALTER TABLE public.sips OWNER TO neondb_owner;

--
-- Name: sips_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.sips_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sips_id_seq OWNER TO neondb_owner;

--
-- Name: sips_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.sips_id_seq OWNED BY public.sips.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    client_id integer,
    transaction_type character varying(20),
    amount numeric(15,2) NOT NULL,
    transaction_date date NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    scheme_name character varying,
    scheme_id integer,
    transaction_id character varying(20),
    platform character varying(50) DEFAULT 'NSE'::character varying,
    notes text
);


ALTER TABLE public.transactions OWNER TO neondb_owner;

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_id_seq OWNER TO neondb_owner;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(100) NOT NULL,
    security_question text DEFAULT 'What is your birth city?'::text,
    security_answer_hash text
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activities id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.activities ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: client_notes id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.client_notes ALTER COLUMN id SET DEFAULT nextval('public.client_notes_id_seq'::regclass);


--
-- Name: client_sequence id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.client_sequence ALTER COLUMN id SET DEFAULT nextval('public.client_sequence_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: market_value_aum id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.market_value_aum ALTER COLUMN id SET DEFAULT nextval('public.market_value_aum_id_seq'::regclass);


--
-- Name: mf_schemes id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.mf_schemes ALTER COLUMN id SET DEFAULT nextval('public.mf_schemes_id_seq'::regclass);


--
-- Name: monthly_analytics id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.monthly_analytics ALTER COLUMN id SET DEFAULT nextval('public.monthly_analytics_id_seq'::regclass);


--
-- Name: playing_with_neon id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.playing_with_neon ALTER COLUMN id SET DEFAULT nextval('public.playing_with_neon_id_seq'::regclass);


--
-- Name: sips id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sips ALTER COLUMN id SET DEFAULT nextval('public.sips_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.activities (id, type, icon, title, description, color, created_at) FROM stdin;
1	client	👤	New Client Onboarded	X (C014) was added to the database.	#0ea5e9	2026-04-10 04:10:30.579842
2	sip	🔄	SIP Modified	SIP parameters for the client were updated.	#10b981	2026-04-11 05:43:16.635782
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.audit_logs (id, entity_type, entity_id, action, performed_by, performed_at) FROM stdin;
\.


--
-- Data for Name: client_notes; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.client_notes (id, client_id, note, created_at) FROM stdin;
\.


--
-- Data for Name: client_sequence; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.client_sequence (id, last_number) FROM stdin;
1	0
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.clients (id, full_name, date_of_birth, age, risk_profile, sourcing_type, created_at, age_bucket, client_added_by, client_sourcing, mobile_number, monthly_income, investment_experience, pan, aadhaar, nominee_name, nominee_relation, nominee_mobile, client_notes, is_active, client_code, onboarding_date, added_by, sourcing, notes, email, dob) FROM stdin;
6	vijay	1993-04-11	\N	Medium	Family / Relative	2026-04-03 21:18:34.367208	\N	\N	\N	8787665544	100000	Beginner	DGTRE5555G	436453674856	dgdgdg	brother	6578566545335	\N	t	C003	2026-04-03	Paras	Internal		hcfhdh@gmail.com	\N
20	A	\N	\N	Medium	Family / Relative	2026-04-05 10:59:58.222267	\N	\N	\N	6567453456	\N	Beginner						\N	t	C009	2026-04-05	Paras	Internal			1992-06-09
22	C	\N	\N	Medium	Family / Relative	2026-04-09 10:10:09.189991	\N	\N	\N	6645464646	\N	Beginner						\N	t	C011	2026-04-09	Paras	Internal			1993-05-03
23	D	\N	\N	Medium	Family / Relative	2026-04-09 10:29:09.263916	\N	\N	\N	4575456777	\N	Beginner						\N	t	C012	2026-04-09	Paras	Internal			1992-04-13
10	hyii gh	1999-04-06	\N	Medium	Family / Relative	2026-04-04 13:16:18.824152	\N	\N	\N	4747566466	\N	Beginner						\N	t	C006	2026-04-02	Paras	Internal			\N
3	Amit	1990-04-07	\N	Medium	Friend	2026-04-03 20:58:19.435784	\N	\N	\N	9875643358	100000	Beginner	GJRYH5976J	747477776970				\N	t	C002	2026-04-01	Paras	Internal		hjfhfhf@gmail.com	\N
24	Y	\N	\N	Medium	Family / Relative	2026-04-10 08:42:19.7645	\N	\N	\N	4646646464	\N	Beginner						\N	t	C013	2026-04-10	Paras	Internal			2001-01-30
25	X	\N	\N	Medium	Family / Relative	2026-04-10 09:40:30.408246	\N	\N	\N	6454545353	\N	Beginner						\N	t	C014	2026-04-10	Paras	Internal			1994-02-01
9	httfg	1993-04-08	\N	Low	Family / Relative	2026-04-04 13:12:02.325938	\N	\N	\N	5483547869	\N	Beginner						\N	t	C005	2026-04-04	Paras	Internal			\N
8	Ram	1998-04-10	\N	Medium	Colleague	2026-04-04 10:39:46.521658	\N	\N	\N	4273547895	50000	Pro						\N	t	C004	2026-04-01	Paras	External			\N
18	uuuuuu	\N	\N	Medium	Family / Relative	2026-04-04 21:04:29.337511	\N	\N	\N	4477665555	\N	Beginner						\N	t	C007	2026-04-05	Paras	Internal			2001-02-05
19	Shyam	\N	\N	Medium	Family / Relative	2026-04-05 08:30:24.40853	\N	\N	\N	6755667788	\N	Beginner						\N	t	C008	2026-04-05	Himanshu	Internal			1994-04-08
\.


--
-- Data for Name: market_value_aum; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.market_value_aum (id, month_year, total_market_value, created_at) FROM stdin;
\.


--
-- Data for Name: mf_schemes; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.mf_schemes (id, scheme_name, amc_name, category, sub_category, created_at, large_cap, mid_cap, small_cap, total_equity, debt, gold, allocation, debt_allocation, gold_allocation, commission_rate, total_current_value) FROM stdin;
2	ICICI Pru Large Cap Fund	ICICI	Equity	Large Cap	2026-04-04 10:52:42.095364	65	20	10	0	0	0	100.00	5.00	0.00	0.90	10000.00
5	SBI Contra Fund	SBI	Equity	Value/Contra	2026-04-04 11:18:19.702378	70	20	5	0	0	0	100.00	5.00	0.00	0.80	20000.00
1	ICICI Pru Multicap Fund	ICICI	Equity	Multi Cap	2026-04-04 08:37:10.913781	25	35	30	90	10	0	100.00	10.00	0.00	0.70	50000.00
6	HDFC Flexi Cap Fund	HDFC	Equity	Flexi Cap	2026-04-04 12:33:23.2322	30	30	20	0	0	0	100.00	20.00	0.00	0.80	10000.00
8	Nippon Large Cap Fund	NIPPON	Equity	Large Cap	2026-04-05 11:15:44.532712	70	10	10	0	0	0	100.00	5.00	5.00	0.80	30000.00
9	Large and Mid cap	HDFC 	Equity	Multi Cap	2026-04-08 16:22:08.235078	65	35	0	0	0	0	100.00	0.00	0.00	0.90	0.00
10	Large and Mid cap	HDFC 	Equity	Multi Cap	2026-04-08 16:22:13.452105	65	35	0	0	0	0	100.00	0.00	0.00	0.90	0.00
11	Large and Mid cap	HDFC 	Equity	Multi Cap	2026-04-08 16:22:34.534654	65	35	0	0	0	0	100.00	0.00	0.00	0.90	0.00
12	Large and Mid cap	HDFC 	Equity	Multi Cap	2026-04-08 16:22:55.682997	65	35	0	0	0	0	100.00	0.00	0.00	0.90	0.00
13	Large and Mid cap	HDFC 	Equity	Multi Cap	2026-04-08 16:23:59.888688	65	35	0	0	0	0	100.00	0.00	0.00	0.90	0.00
14	Motilal Oswal Mid Cap Fund	Motilal Oswal	Equity	Mid Cap	2026-04-09 04:29:09.823354	40	40	10	0	0	0	100.00	5.00	5.00	0.60	6000.00
15	Kotak Flexi Cap Fund	KOTAK	Equity	Flexi Cap	2026-04-09 10:32:55.348004	70	10	10	0	0	0	100.00	5.00	5.00	0.90	17000.00
7	Bandhan Small Cap Fund	BANDHAN	Equity	Small Cap	2026-04-05 08:39:18.003083	20	30	40	0	0	0	100.00	5.00	5.00	0.20	6000.00
\.


--
-- Data for Name: monthly_analytics; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.monthly_analytics (id, snapshot_date, total_invested, total_market_value, sip_book_amount, actual_commission) FROM stdin;
\.


--
-- Data for Name: playing_with_neon; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.playing_with_neon (id, name, value) FROM stdin;
1	c4ca4238a0	0.7044798
2	c81e728d9d	0.2459078
3	eccbc87e4b	0.01152023
4	a87ff679a2	0.2788375
5	e4da3b7fbb	0.5601388
6	1679091c5a	0.47524786
7	8f14e45fce	0.03191096
8	c9f0f895fb	0.020466698
9	45c48cce2e	0.9835051
10	d3d9446802	0.8910746
\.


--
-- Data for Name: sips; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sips (id, client_id, frequency, start_date, end_date, is_active, created_at, sip_day, status, stopped_at, scheme_name, platform, notes, sip_id, scheme_id, amount) FROM stdin;
3	3	MONTHLY	2025-01-01	\N	t	2026-04-04 10:10:29.834179	1	Active	\N	\N	NSE		SID00001	1	10000.00
4	6	MONTHLY	2026-04-04	\N	t	2026-04-04 10:20:25.943152	1	Active	\N	\N	NSE		SID00002	1	20000.00
6	20	MONTHLY	2026-04-05	\N	t	2026-04-05 11:14:32.20965	1	Active	\N	\N	NSE		SID00004	7	2000.00
7	23	MONTHLY	2026-04-09	\N	t	2026-04-09 10:30:06.292068	2	Active	\N	\N	NSE		SID00005	14	40000.00
5	8	MONTHLY	2025-05-06	2026-05-05	t	2026-04-05 08:36:43.123706	4	Active	\N	\N	NSE		SID00003	6	15000.00
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.transactions (id, client_id, transaction_type, amount, transaction_date, created_at, scheme_name, scheme_id, transaction_id, platform, notes) FROM stdin;
9	3	Purchase	50000.00	2026-04-04	2026-04-04 09:05:24.981964	\N	1	TID00009	NSE	\N
10	6	Purchase	5000.00	2026-04-03	2026-04-04 09:14:41.387619	\N	1	TID00010	Cams	
11	6	Purchase	30000.00	2026-04-04	2026-04-04 10:37:10.022753	\N	1	TID00011	Kfin	
12	8	Switch Out	5000.00	2026-04-04	2026-04-04 10:53:22.292506	\N	1	TID00012-OUT	Cams	
13	8	Switch In	5000.00	2026-04-04	2026-04-04 10:53:22.622393	\N	2	TID00012-IN	Cams	
14	3	Purchase	30000.00	2026-04-04	2026-04-04 11:19:04.862945	\N	5	TID00013	NSE	
15	9	Purchase	20000.00	2026-04-05	2026-04-05 08:37:27.423921	\N	6	TID00014	NSE	
16	10	Purchase	4000.00	2026-04-05	2026-04-05 08:42:10.346353	\N	7	TID00015	Kfin	
17	20	Purchase	3000.00	2026-04-05	2026-04-05 11:14:50.524553	\N	7	TID00016	NSE	
18	23	Purchase	7000.00	2026-04-03	2026-04-09 10:30:50.759152	\N	14	TID00017	NSE	
19	9	Purchase	5000.00	2026-04-07	2026-04-09 16:36:41.727834	\N	12	TID00018	NSE	New Lumsum 
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, username, password_hash, full_name, security_question, security_answer_hash) FROM stdin;
2	himanshu	$2b$10$NcTiVzvnlUtueEigsqA.n.vHMEscW3sTUHUPBiGX.KqwHG2T1zLC2	Himanshu	What is your birth city?	$2a$10$p6G6/XpMvV8H/C1L9l5yyeZ8r7O3z6G6/XpMvV8H/C1L9l5yyeZ8r
1	paras	$2b$10$pejRq3CLxszifTDMvVYCoe3z2ebz.cnLm.W6Yf9WAQp6sYf5uGCUu	Paras	What is your birth city?	$2b$10$q9rSVu3YQUo/XdToTKiaoekSyk0uIw54VrgdvrVDwFs14miYwRXra
\.


--
-- Name: activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.activities_id_seq', 2, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: client_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.client_notes_id_seq', 1, false);


--
-- Name: client_sequence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.client_sequence_id_seq', 1, true);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.clients_id_seq', 25, true);


--
-- Name: market_value_aum_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.market_value_aum_id_seq', 1, false);


--
-- Name: mf_schemes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.mf_schemes_id_seq', 15, true);


--
-- Name: monthly_analytics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.monthly_analytics_id_seq', 1, false);


--
-- Name: playing_with_neon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.playing_with_neon_id_seq', 10, true);


--
-- Name: sips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.sips_id_seq', 7, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.transactions_id_seq', 19, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: client_notes client_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.client_notes
    ADD CONSTRAINT client_notes_pkey PRIMARY KEY (id);


--
-- Name: client_sequence client_sequence_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.client_sequence
    ADD CONSTRAINT client_sequence_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: market_value_aum market_value_aum_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.market_value_aum
    ADD CONSTRAINT market_value_aum_pkey PRIMARY KEY (id);


--
-- Name: mf_schemes mf_schemes_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.mf_schemes
    ADD CONSTRAINT mf_schemes_pkey PRIMARY KEY (id);


--
-- Name: monthly_analytics monthly_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.monthly_analytics
    ADD CONSTRAINT monthly_analytics_pkey PRIMARY KEY (id);


--
-- Name: playing_with_neon playing_with_neon_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.playing_with_neon
    ADD CONSTRAINT playing_with_neon_pkey PRIMARY KEY (id);


--
-- Name: sips sips_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_pkey PRIMARY KEY (id);


--
-- Name: sips sips_sip_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_sip_id_key UNIQUE (sip_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_clients_client_code; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX idx_clients_client_code ON public.clients USING btree (client_code);


--
-- Name: client_notes client_notes_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.client_notes
    ADD CONSTRAINT client_notes_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: sips sips_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: sips sips_scheme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_scheme_id_fkey FOREIGN KEY (scheme_id) REFERENCES public.mf_schemes(id);


--
-- Name: transactions transactions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_scheme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_scheme_id_fkey FOREIGN KEY (scheme_id) REFERENCES public.mf_schemes(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

\unrestrict X7F7JsnyxpaCtafVoLjvf7JXDNUubJHO1LpDgLPoiDEpb5NJeCCX5iZ1uwDChFQ

